package edu.uj.po.interfaces;

/**
 * Bierki szachowe
 */
public enum ChessPiece {
	BISHOP, KING, KNIGHT, PAWN, QUEEN, ROOK;
}
