package Board;

import Pieces.Piece;

public interface EnPassantHandler {
    public void HandleEnPassant(Piece piece);
}
